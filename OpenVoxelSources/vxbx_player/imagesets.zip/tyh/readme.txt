Taken from the Radiohead House of Cards video

Frame 1000 

Open the ply file with meshlab to see the point cloud

Converted from csv using csv2ply.py

Cropped and centered using plyProcessor.py